"use client"

import { useState, useEffect } from "react"
import { SimpleCalendar } from "@/components/simple-calendar"
import { SimpleTaskManager } from "@/components/simple-task-manager"
import { PomodoroTimer } from "@/components/pomodoro-timer"
import { VirtualPlant } from "@/components/virtual-plant"
import { StudyChatbot } from "@/components/study-chatbot"
import { CreativeThemeToggle } from "@/components/creative-theme-toggle"
import { EnhancedMusicPlayer } from "@/components/enhanced-music-player"
import { CreativeBackground } from "@/components/creative-background"
import { Card } from "@/components/ui/card"

// Define task type
export interface Task {
  id: string
  text: string
  completed: boolean
  timeSpent: number
}

export default function StudyBuddy() {
  // Simple state management
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [allTasks, setAllTasks] = useState<Record<string, Task[]>>({})
  const [isOnBreak, setIsOnBreak] = useState(false)
  const [theme, setTheme] = useState("light-academia")

  // Format date as string key (dd/mm/yyyy format)
  const formatDateKey = (date: Date) => {
    const day = date.getDate().toString().padStart(2, "0")
    const month = (date.getMonth() + 1).toString().padStart(2, "0")
    const year = date.getFullYear()
    return `${day}/${month}/${year}`
  }

  const dateKey = formatDateKey(selectedDate)

  // Get tasks for current date
  const currentTasks = allTasks[dateKey] || []

  // Calculate stats
  const completedTasks = currentTasks.filter((task) => task.completed).length
  const totalTasks = currentTasks.length

  // Load tasks from localStorage on mount
  useEffect(() => {
    try {
      const savedTasks = localStorage.getItem("study-buddy-tasks")
      if (savedTasks) {
        setAllTasks(JSON.parse(savedTasks))
      }
    } catch (error) {
      console.error("Error loading tasks:", error)
    }

    // Load theme
    const savedTheme = localStorage.getItem("study-buddy-theme") || "light-academia"
    setTheme(savedTheme)
    applyTheme(savedTheme)
  }, [])

  // Save tasks to localStorage when they change
  useEffect(() => {
    try {
      localStorage.setItem("study-buddy-tasks", JSON.stringify(allTasks))
    } catch (error) {
      console.error("Error saving tasks:", error)
    }
  }, [allTasks])

  // Apply theme function with proper CSS variables
  const applyTheme = (themeId: string) => {
    // Remove all existing theme classes
    document.documentElement.className = document.documentElement.className
      .split(" ")
      .filter((cls) => !cls.startsWith("theme-"))
      .join(" ")

    // Add new theme class
    document.documentElement.classList.add(`theme-${themeId}`)

    // Update CSS custom properties based on theme
    const root = document.documentElement
    const themes: Record<string, Record<string, string>> = {
      "light-academia": {
        "--bg-primary": "#f8f5f0",
        "--bg-secondary": "#ffffff",
        "--text-primary": "#2c2c2c",
        "--text-secondary": "#8b7355",
        "--accent": "#c19a6b",
        "--border": "#e0d6c8",
        "--shadow": "rgba(139, 115, 85, 0.1)",
        "--gradient-start": "#f8f5f0",
        "--gradient-end": "#e0d6c8",
      },
      "dark-academia": {
        "--bg-primary": "#2c2418",
        "--bg-secondary": "#3a3026",
        "--text-primary": "#e8e0d5",
        "--text-secondary": "#c19a6b",
        "--accent": "#d4b483",
        "--border": "#5a4a3a",
        "--shadow": "rgba(212, 180, 131, 0.2)",
        "--gradient-start": "#2c2418",
        "--gradient-end": "#4a3d2a",
      },
      "aesthetic-pink": {
        "--bg-primary": "#fdf2f8",
        "--bg-secondary": "#fce7f3",
        "--text-primary": "#831843",
        "--text-secondary": "#ec4899",
        "--accent": "#be185d",
        "--border": "#f9a8d4",
        "--shadow": "rgba(236, 72, 153, 0.2)",
        "--gradient-start": "#fdf2f8",
        "--gradient-end": "#fbcfe8",
      },
      "aesthetic-purple": {
        "--bg-primary": "#faf5ff",
        "--bg-secondary": "#f3e8ff",
        "--text-primary": "#581c87",
        "--text-secondary": "#a855f7",
        "--accent": "#7c3aed",
        "--border": "#c4b5fd",
        "--shadow": "rgba(168, 85, 247, 0.2)",
        "--gradient-start": "#faf5ff",
        "--gradient-end": "#e9d5ff",
      },
      cyberpunk: {
        "--bg-primary": "#0c0a09",
        "--bg-secondary": "#1c1917",
        "--text-primary": "#00ff88",
        "--text-secondary": "#ff0080",
        "--accent": "#00ccff",
        "--border": "#44403c",
        "--shadow": "rgba(0, 255, 136, 0.3)",
        "--gradient-start": "#0c0a09",
        "--gradient-end": "#18181b",
      },
      cottagecore: {
        "--bg-primary": "#f0fdf4",
        "--bg-secondary": "#dcfce7",
        "--text-primary": "#365314",
        "--text-secondary": "#65a30d",
        "--accent": "#4d7c0f",
        "--border": "#bbf7d0",
        "--shadow": "rgba(101, 163, 13, 0.2)",
        "--gradient-start": "#f0fdf4",
        "--gradient-end": "#dcfce7",
      },
      "chic-minimal": {
        "--bg-primary": "#fafafa",
        "--bg-secondary": "#ffffff",
        "--text-primary": "#262626",
        "--text-secondary": "#525252",
        "--accent": "#404040",
        "--border": "#e5e5e5",
        "--shadow": "rgba(64, 64, 64, 0.1)",
        "--gradient-start": "#fafafa",
        "--gradient-end": "#f5f5f5",
      },
      "chic-gold": {
        "--bg-primary": "#fffbeb",
        "--bg-secondary": "#fef3c7",
        "--text-primary": "#92400e",
        "--text-secondary": "#d97706",
        "--accent": "#b45309",
        "--border": "#fcd34d",
        "--shadow": "rgba(217, 119, 6, 0.2)",
        "--gradient-start": "#fffbeb",
        "--gradient-end": "#fef3c7",
      },
      "forest-green": {
        "--bg-primary": "#064e3b",
        "--bg-secondary": "#065f46",
        "--text-primary": "#d1fae5",
        "--text-secondary": "#10b981",
        "--accent": "#34d399",
        "--border": "#047857",
        "--shadow": "rgba(16, 185, 129, 0.3)",
        "--gradient-start": "#064e3b",
        "--gradient-end": "#065f46",
      },
      "ocean-blue": {
        "--bg-primary": "#0c4a6e",
        "--bg-secondary": "#0369a1",
        "--text-primary": "#dbeafe",
        "--text-secondary": "#0ea5e9",
        "--accent": "#38bdf8",
        "--border": "#0284c7",
        "--shadow": "rgba(14, 165, 233, 0.3)",
        "--gradient-start": "#0c4a6e",
        "--gradient-end": "#0369a1",
      },
      "sunset-orange": {
        "--bg-primary": "#7c2d12",
        "--bg-secondary": "#ea580c",
        "--text-primary": "#fed7aa",
        "--text-secondary": "#fb923c",
        "--accent": "#fdba74",
        "--border": "#f97316",
        "--shadow": "rgba(251, 146, 60, 0.3)",
        "--gradient-start": "#7c2d12",
        "--gradient-end": "#c2410c",
      },
      "lavender-dreams": {
        "--bg-primary": "#f8fafc",
        "--bg-secondary": "#ede9fe",
        "--text-primary": "#581c87",
        "--text-secondary": "#a78bfa",
        "--accent": "#8b5cf6",
        "--border": "#c4b5fd",
        "--shadow": "rgba(167, 139, 250, 0.2)",
        "--gradient-start": "#f8fafc",
        "--gradient-end": "#ede9fe",
      },
      "rose-gold": {
        "--bg-primary": "#fef7f0",
        "--bg-secondary": "#fed7aa",
        "--text-primary": "#9a3412",
        "--text-secondary": "#ea580c",
        "--accent": "#c2410c",
        "--border": "#fdba74",
        "--shadow": "rgba(234, 88, 12, 0.2)",
        "--gradient-start": "#fef7f0",
        "--gradient-end": "#fed7aa",
      },
      "mint-fresh": {
        "--bg-primary": "#f0fdfa",
        "--bg-secondary": "#ccfbf1",
        "--text-primary": "#134e4a",
        "--text-secondary": "#14b8a6",
        "--accent": "#0f766e",
        "--border": "#99f6e4",
        "--shadow": "rgba(20, 184, 166, 0.2)",
        "--gradient-start": "#f0fdfa",
        "--gradient-end": "#ccfbf1",
      },
      "coffee-brown": {
        "--bg-primary": "#451a03",
        "--bg-secondary": "#78350f",
        "--text-primary": "#fef3c7",
        "--text-secondary": "#d97706",
        "--accent": "#fbbf24",
        "--border": "#92400e",
        "--shadow": "rgba(217, 119, 6, 0.3)",
        "--gradient-start": "#451a03",
        "--gradient-end": "#78350f",
      },
      "midnight-black": {
        "--bg-primary": "#000000",
        "--bg-secondary": "#1e293b",
        "--text-primary": "#f8fafc",
        "--text-secondary": "#64748b",
        "--accent": "#94a3b8",
        "--border": "#334155",
        "--shadow": "rgba(148, 163, 184, 0.3)",
        "--gradient-start": "#000000",
        "--gradient-end": "#1e293b",
      },
      "cream-beige": {
        "--bg-primary": "#fefce8",
        "--bg-secondary": "#fef3c7",
        "--text-primary": "#713f12",
        "--text-secondary": "#ca8a04",
        "--accent": "#a16207",
        "--border": "#fde047",
        "--shadow": "rgba(202, 138, 4, 0.2)",
        "--gradient-start": "#fefce8",
        "--gradient-end": "#fef3c7",
      },
      "sage-green": {
        "--bg-primary": "#f6f7f6",
        "--bg-secondary": "#e6fffa",
        "--text-primary": "#2d3748",
        "--text-secondary": "#68d391",
        "--accent": "#38a169",
        "--border": "#9ae6b4",
        "--shadow": "rgba(104, 211, 145, 0.2)",
        "--gradient-start": "#f6f7f6",
        "--gradient-end": "#e6fffa",
      },
      "dusty-rose": {
        "--bg-primary": "#fdf2f8",
        "--bg-secondary": "#fce7f3",
        "--text-primary": "#702459",
        "--text-secondary": "#db2777",
        "--accent": "#be185d",
        "--border": "#f9a8d4",
        "--shadow": "rgba(219, 39, 119, 0.2)",
        "--gradient-start": "#fdf2f8",
        "--gradient-end": "#fce7f3",
      },
      "vintage-blue": {
        "--bg-primary": "#eff6ff",
        "--bg-secondary": "#dbeafe",
        "--text-primary": "#1e3a8a",
        "--text-secondary": "#3b82f6",
        "--accent": "#2563eb",
        "--border": "#93c5fd",
        "--shadow": "rgba(59, 130, 246, 0.2)",
        "--gradient-start": "#eff6ff",
        "--gradient-end": "#dbeafe",
      },
    }

    const themeVars = themes[themeId] || themes["light-academia"]
    Object.entries(themeVars).forEach(([property, value]) => {
      root.style.setProperty(property, value)
    })

    // Apply body background
    document.body.style.backgroundColor = themeVars["--bg-primary"]
    document.body.style.color = themeVars["--text-primary"]
  }

  // Update tasks for current date
  const updateTasks = (tasks: Task[]) => {
    setAllTasks((prev) => ({
      ...prev,
      [dateKey]: tasks,
    }))
  }

  // Change theme
  const changeTheme = (newTheme: string) => {
    setTheme(newTheme)
    applyTheme(newTheme)
    localStorage.setItem("study-buddy-theme", newTheme)
  }

  // Format date for display (dd/mm/yyyy)
  const formatDisplayDate = (date: Date) => {
    const day = date.getDate().toString().padStart(2, "0")
    const month = (date.getMonth() + 1).toString().padStart(2, "0")
    const year = date.getFullYear()
    return `${day}/${month}/${year}`
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Creative Background */}
      <CreativeBackground theme={theme} />

      <div className="relative z-10 p-6">
        {/* Header with Study Buddy Title */}
        <div className="flex items-center justify-between mb-8">
          <div className="animate-fade-in">
            <h1 className="text-5xl font-bold mb-2 study-buddy-title">Study Buddy ✨</h1>
            <p className="text-lg opacity-80 italic study-buddy-subtitle">Your magical productivity companion</p>
          </div>
          <div className="animate-slide-in-right">
            <CreativeThemeToggle currentTheme={theme} onThemeChange={changeTheme} />
          </div>
        </div>

        {/* Pomodoro Timer */}
        <div className="mb-8 animate-fade-in-up">
          <PomodoroTimer onBreakChange={setIsOnBreak} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Calendar & Music */}
          <div className="space-y-8 animate-slide-in-left">
            <Card className="themed-card p-6">
              <SimpleCalendar
                selectedDate={selectedDate}
                onDateSelect={setSelectedDate}
                tasks={allTasks}
                formatDateKey={formatDateKey}
                formatDisplayDate={formatDisplayDate}
              />
            </Card>
            <div className="animate-fade-in-up delay-200">
              <EnhancedMusicPlayer />
            </div>
          </div>

          {/* Middle Column - Tasks */}
          <div className="animate-fade-in-up delay-100">
            <Card className="themed-card p-6">
              <SimpleTaskManager
                selectedDate={selectedDate}
                tasks={currentTasks}
                onTasksUpdate={updateTasks}
                formatDisplayDate={formatDisplayDate}
              />
            </Card>
          </div>

          {/* Right Column - Plant & Chatbot */}
          <div className="space-y-8 animate-slide-in-right">
            <Card className="themed-card p-6">
              <VirtualPlant
                completedTasks={completedTasks}
                totalTasks={totalTasks}
                isAllCompleted={totalTasks > 0 && completedTasks === totalTasks}
              />
            </Card>
            <div className="animate-fade-in-up delay-300">
              <Card className="themed-card p-6">
                <StudyChatbot isOnBreak={isOnBreak} />
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
