"use client"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, Volume2, VolumeX, SkipForward, SkipBack } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Track {
  id: string
  title: string
  artist: string
  duration: string
  genre: string
}

const studyTracks: Track[] = [
  { id: "1", title: "Forest Rain", artist: "Nature Sounds", duration: "10:00", genre: "Ambient" },
  { id: "2", title: "Coffee Shop Jazz", artist: "Study Beats", duration: "8:30", genre: "Jazz" },
  { id: "3", title: "Ocean Waves", artist: "Relaxation", duration: "12:00", genre: "Nature" },
  { id: "4", title: "Piano Focus", artist: "Classical Study", duration: "6:45", genre: "Classical" },
  { id: "5", title: "White Noise", artist: "Concentration", duration: "15:00", genre: "Ambient" },
  { id: "6", title: "Lofi Hip Hop", artist: "Chill Beats", duration: "7:20", genre: "Lofi" },
  { id: "7", title: "Thunderstorm", artist: "Weather Sounds", duration: "9:15", genre: "Nature" },
  { id: "8", title: "Meditation Bells", artist: "Zen Music", duration: "11:30", genre: "Meditation" },
]

export function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTrack, setCurrentTrack] = useState(0)
  const [volume, setVolume] = useState([70])
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const audioRef = useRef<HTMLAudioElement>(null)

  // Simulate audio playback (since we don't have actual audio files)
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          const maxTime =
            Number.parseInt(studyTracks[currentTrack].duration.split(":")[0]) * 60 +
            Number.parseInt(studyTracks[currentTrack].duration.split(":")[1])
          if (prev >= maxTime) {
            nextTrack()
            return 0
          }
          return prev + 1
        })
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isPlaying, currentTrack])

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  const nextTrack = () => {
    setCurrentTrack((prev) => (prev + 1) % studyTracks.length)
    setCurrentTime(0)
  }

  const previousTrack = () => {
    setCurrentTrack((prev) => (prev - 1 + studyTracks.length) % studyTracks.length)
    setCurrentTime(0)
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getCurrentDuration = () => {
    const [mins, secs] = studyTracks[currentTrack].duration.split(":").map(Number)
    return mins * 60 + secs
  }

  const progress = (currentTime / getCurrentDuration()) * 100

  return (
    <Card className="card-enhanced p-6">
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-elegant gradient-text mb-2">Study Music</h3>
        <p className="text-sm text-muted-elegant">Focus-enhancing ambient sounds</p>
      </div>

      {/* Current Track Display */}
      <div className="mb-6 text-center">
        <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg">
          <div className="text-2xl">🎵</div>
        </div>
        <h4 className="font-semibold text-elegant mb-1">{studyTracks[currentTrack].title}</h4>
        <p className="text-sm text-muted-elegant">{studyTracks[currentTrack].artist}</p>
        <span className="inline-block px-2 py-1 text-xs bg-purple-500/20 text-purple-400 rounded-full mt-2">
          {studyTracks[currentTrack].genre}
        </span>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="progress-elegant h-2 mb-2">
          <div
            className="progress-fill bg-gradient-to-r from-purple-500 to-pink-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-muted-elegant">
          <span>{formatTime(currentTime)}</span>
          <span>{studyTracks[currentTrack].duration}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center space-x-4 mb-6">
        <Button variant="ghost" size="sm" onClick={previousTrack} className="p-2 rounded-full hover:bg-purple-500/20">
          <SkipBack className="h-5 w-5" />
        </Button>

        <Button
          onClick={togglePlay}
          className={cn(
            "w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg",
            "hover:shadow-xl transition-all duration-200",
          )}
        >
          {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
        </Button>

        <Button variant="ghost" size="sm" onClick={nextTrack} className="p-2 rounded-full hover:bg-purple-500/20">
          <SkipForward className="h-5 w-5" />
        </Button>
      </div>

      {/* Volume Control */}
      <div className="flex items-center space-x-3">
        <Button variant="ghost" size="sm" onClick={toggleMute} className="p-2 rounded-full hover:bg-purple-500/20">
          {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>
        <Slider value={isMuted ? [0] : volume} onValueChange={setVolume} max={100} step={1} className="flex-1" />
        <span className="text-xs text-muted-elegant w-8">{isMuted ? 0 : volume[0]}</span>
      </div>

      {/* Track List */}
      <div className="mt-6 max-h-32 overflow-y-auto">
        <h5 className="text-sm font-semibold text-elegant mb-3">Playlist</h5>
        <div className="space-y-2">
          {studyTracks.map((track, index) => (
            <button
              key={track.id}
              onClick={() => {
                setCurrentTrack(index)
                setCurrentTime(0)
              }}
              className={cn(
                "w-full text-left p-2 rounded-lg transition-all duration-200 text-xs",
                index === currentTrack ? "bg-purple-500/20 text-purple-400" : "hover:bg-white/5 text-muted-elegant",
              )}
            >
              <div className="flex justify-between items-center">
                <div>
                  <div className="font-medium">{track.title}</div>
                  <div className="opacity-70">{track.artist}</div>
                </div>
                <div className="text-right">
                  <div>{track.duration}</div>
                  <div className="opacity-70">{track.genre}</div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </Card>
  )
}
