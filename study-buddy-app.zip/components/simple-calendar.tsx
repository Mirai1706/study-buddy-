"use client"

import { useState } from "react"
import type { Task } from "@/app/page"
import { Button } from "@/components/ui/button"

interface SimpleCalendarProps {
  selectedDate: Date
  onDateSelect: (date: Date) => void
  tasks: Record<string, Task[]>
  formatDateKey: (date: Date) => string
  formatDisplayDate: (date: Date) => string
}

export function SimpleCalendar({
  selectedDate,
  onDateSelect,
  tasks,
  formatDateKey,
  formatDisplayDate,
}: SimpleCalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date())

  // Get current month details
  const year = currentMonth.getFullYear()
  const month = currentMonth.getMonth()
  const firstDay = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()

  // Month navigation
  const prevMonth = () => setCurrentMonth(new Date(year, month - 1, 1))
  const nextMonth = () => setCurrentMonth(new Date(year, month + 1, 1))

  // Month names
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  // Day names
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  // Check if a date has tasks
  const getTaskInfo = (date: Date) => {
    const dateKey = formatDateKey(date)
    const dateTasks = tasks[dateKey] || []

    if (dateTasks.length === 0) return null

    const completed = dateTasks.filter((task) => task.completed).length
    return {
      total: dateTasks.length,
      completed,
    }
  }

  // Generate calendar days
  const generateCalendarDays = () => {
    const days = []

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-10" />)
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day)
      const isToday = new Date().toDateString() === date.toDateString()
      const isSelected = selectedDate.toDateString() === date.toDateString()
      const taskInfo = getTaskInfo(date)

      days.push(
        <button
          key={day}
          onClick={() => onDateSelect(date)}
          className={`h-10 w-full rounded flex flex-col items-center justify-center relative transition-all duration-200 hover:scale-105 ${
            isSelected
              ? "themed-button-selected scale-110 shadow-lg"
              : isToday
                ? "themed-button-today border-2 font-bold"
                : "themed-button hover:bg-opacity-20"
          }`}
        >
          <span className="relative z-10">{day}</span>
          {taskInfo && (
            <div className="absolute bottom-1 flex gap-1">
              {taskInfo.completed > 0 && <div className="w-2 h-2 rounded-full bg-green-500 shadow-sm" />}
              {taskInfo.completed < taskInfo.total && <div className="w-2 h-2 rounded-full bg-yellow-500 shadow-sm" />}
            </div>
          )}
        </button>,
      )
    }

    return days
  }

  return (
    <div>
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold themed-text">
          {monthNames[month]} {year}
        </h2>
        <div className="flex gap-2">
          <Button size="sm" onClick={prevMonth} className="themed-button">
            ←
          </Button>
          <Button size="sm" onClick={nextMonth} className="themed-button">
            →
          </Button>
        </div>
      </div>

      {/* Day names */}
      <div className="grid grid-cols-7 gap-1 mb-1">
        {dayNames.map((day) => (
          <div key={day} className="text-center text-sm font-medium themed-text-secondary p-2">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1 mb-4">{generateCalendarDays()}</div>

      {/* Selected date display */}
      <div className="text-center p-3 themed-card-inner rounded-lg">
        <p className="text-sm themed-text-secondary">Selected Date</p>
        <p className="font-bold themed-text">{formatDisplayDate(selectedDate)}</p>
      </div>

      {/* Legend */}
      <div className="mt-4 flex justify-center gap-4 text-xs">
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-green-500" />
          <span className="themed-text-secondary">Completed</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-yellow-500" />
          <span className="themed-text-secondary">Pending</span>
        </div>
      </div>
    </div>
  )
}
