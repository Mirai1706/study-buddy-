"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Plus, Play, Pause, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
// Remove this import
// import { Checkbox } from "@/components/ui/checkbox"
import { cn } from "@/lib/utils"

interface Task {
  id: string
  text: string
  completed: boolean
  timeSpent: number
  isRunning: boolean
}

interface TaskManagerProps {
  selectedDate: Date
  tasks: Task[]
  onTasksUpdate: (tasks: Task[]) => void
}

export function TaskManager({ selectedDate, tasks, onTasksUpdate }: TaskManagerProps) {
  const [newTaskText, setNewTaskText] = useState("")
  const [timers, setTimers] = useState<Record<string, NodeJS.Timeout>>({})
  const timersRef = useRef<Record<string, NodeJS.Timeout>>({})

  // Store timers in ref to avoid dependency issues
  useEffect(() => {
    timersRef.current = timers
  }, [timers])

  // Clear all timers when component unmounts
  useEffect(() => {
    return () => {
      Object.values(timersRef.current).forEach((timer) => clearInterval(timer))
    }
  }, [])

  // Stop all running timers when date changes but keep tasks
  useEffect(() => {
    stopAllTimers()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate])

  const stopAllTimers = () => {
    Object.values(timersRef.current).forEach((timer) => clearInterval(timer))
    setTimers({})

    // Stop all running tasks but keep the tasks themselves
    if (Array.isArray(tasks) && tasks.length > 0) {
      const updatedTasks = tasks.map((task) => ({ ...task, isRunning: false }))
      onTasksUpdate(updatedTasks)
    }
  }

  const addTask = () => {
    if (newTaskText.trim()) {
      const newTask: Task = {
        id: Date.now().toString(),
        text: newTaskText.trim(),
        completed: false,
        timeSpent: 0,
        isRunning: false,
      }
      const currentTasks = Array.isArray(tasks) ? tasks : []
      onTasksUpdate([...currentTasks, newTask])
      setNewTaskText("")
    }
  }

  const toggleTaskCompletion = (taskId: string) => {
    if (!Array.isArray(tasks)) return

    // Stop timer if task is being completed
    if (timers[taskId]) {
      clearInterval(timers[taskId])
      setTimers((prev) => {
        const newTimers = { ...prev }
        delete newTimers[taskId]
        return newTimers
      })
    }

    const updatedTasks = tasks.map((task) =>
      task.id === taskId ? { ...task, completed: !task.completed, isRunning: false } : task,
    )
    onTasksUpdate(updatedTasks)
  }

  const toggleTimer = (taskId: string) => {
    if (!Array.isArray(tasks)) return

    const task = tasks.find((t) => t.id === taskId)
    if (!task || task.completed) return

    if (task.isRunning) {
      // Stop timer
      if (timers[taskId]) {
        clearInterval(timers[taskId])
        setTimers((prev) => {
          const newTimers = { ...prev }
          delete newTimers[taskId]
          return newTimers
        })
      }

      const updatedTasks = tasks.map((t) => (t.id === taskId ? { ...t, isRunning: false } : t))
      onTasksUpdate(updatedTasks)
    } else {
      // Start timer
      const timer = setInterval(() => {
        onTasksUpdate((prevTasks) => {
          if (!Array.isArray(prevTasks)) return []
          return prevTasks.map((t) => (t.id === taskId ? { ...t, timeSpent: t.timeSpent + 1 } : t))
        })
      }, 1000)

      setTimers((prev) => ({ ...prev, [taskId]: timer }))

      const updatedTasks = tasks.map((t) => (t.id === taskId ? { ...t, isRunning: true } : t))
      onTasksUpdate(updatedTasks)
    }
  }

  const deleteTask = (taskId: string) => {
    if (!Array.isArray(tasks)) return

    if (timers[taskId]) {
      clearInterval(timers[taskId])
      setTimers((prev) => {
        const newTimers = { ...prev }
        delete newTimers[taskId]
        return newTimers
      })
    }
    onTasksUpdate(tasks.filter((task) => task.id !== taskId))
  }

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    }
    return `${minutes}:${secs.toString().padStart(2, "0")}`
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      addTask()
    }
  }

  const completedTasksCount = Array.isArray(tasks) ? tasks.filter((task) => task && task.completed).length : 0
  const totalTasksCount = Array.isArray(tasks) ? tasks.length : 0
  const totalTime = Array.isArray(tasks) ? tasks.reduce((sum, task) => sum + (task?.timeSpent || 0), 0) : 0

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-elegant gradient-text">Tasks for {selectedDate.toLocaleDateString()}</h2>
        <div className="text-sm text-muted-elegant font-medium">
          {completedTasksCount}/{totalTasksCount} completed
        </div>
      </div>

      {/* Add Task Input */}
      <div className="flex space-x-2 mb-6">
        <Input
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Add a new task..."
          className="flex-1 input-elegant"
        />
        <Button onClick={addTask} className="btn-elegant">
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      {/* Task List */}
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {!Array.isArray(tasks) || tasks.length === 0 ? (
          <div className="text-center py-8 text-muted-elegant">No tasks for this day. Add one to get started!</div>
        ) : (
          tasks.map((task) => (
            <Card
              key={task.id}
              className={cn(
                "task-item p-4 transition-all duration-200",
                task.completed
                  ? "completed bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-400/30"
                  : "bg-gradient-to-r from-white/5 to-white/10 dark:from-black/5 dark:to-black/10 border-white/20 dark:border-white/10",
              )}
            >
              <div className="flex items-center space-x-3">
                {/* Checkbox for task completion */}
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={() => toggleTaskCompletion(task.id)}
                  className="w-5 h-5 rounded border-2 border-amber-400 text-amber-600 focus:ring-amber-500 focus:ring-2"
                />

                {/* Task text */}
                <span
                  className={cn(
                    "flex-1 text-sm",
                    task.completed ? "line-through text-green-700 dark:text-green-400" : "text-elegant",
                  )}
                >
                  {task.text}
                </span>

                {/* Timer display */}
                <div className="text-sm font-mono text-muted-elegant min-w-[60px] text-right">
                  {formatTime(task.timeSpent)}
                </div>

                {/* Timer controls */}
                {!task.completed && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleTimer(task.id)}
                    className={cn(
                      "p-2 rounded-full",
                      task.isRunning
                        ? "text-red-600 hover:text-red-700 bg-red-100 dark:bg-red-900/20"
                        : "text-green-600 hover:text-green-700 bg-green-100 dark:bg-green-900/20",
                    )}
                  >
                    {task.isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                )}

                {/* Delete button */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteTask(task.id)}
                  className="p-2 rounded-full text-red-600 hover:text-red-700 bg-red-100 dark:bg-red-900/20"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Summary */}
      {Array.isArray(tasks) && tasks.length > 0 && (
        <div className="mt-6 p-4 glass rounded-lg">
          <div className="text-sm text-muted-elegant space-y-1">
            <div>Total study time: {formatTime(totalTime)}</div>
            <div>Progress: {totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0}%</div>
          </div>
        </div>
      )}
    </div>
  )
}
