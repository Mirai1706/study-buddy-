"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, SkipForward, SkipBack, Upload, Trash2, Music, Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface UserTrack {
  id: string
  title: string
  artist: string | null
  url: string
  duration: number
  color: string
}

export function EnhancedMusicPlayer() {
  const [tracks, setTracks] = useState<UserTrack[]>([])
  const [currentTrack, setCurrentTrack] = useState<number | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(70)
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [dragActive, setDragActive] = useState(false)
  const [showUploadTip, setShowUploadTip] = useState(true)

  const audioRef = useRef<HTMLAudioElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Load tracks from localStorage
  useEffect(() => {
    try {
      const savedTracks = localStorage.getItem("study-buddy-music")
      if (savedTracks) {
        const parsedTracks = JSON.parse(savedTracks)
        setTracks(parsedTracks)
        setShowUploadTip(parsedTracks.length === 0)
      }
    } catch (error) {
      console.error("Error loading tracks:", error)
    }
  }, [])

  // Save tracks to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("study-buddy-music", JSON.stringify(tracks))
      setShowUploadTip(tracks.length === 0)
    } catch (error) {
      console.error("Error saving tracks:", error)
    }
  }, [tracks])

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const updateTime = () => setCurrentTime(audio.currentTime)
    const updateDuration = () => {
      if (!isNaN(audio.duration)) {
        setDuration(audio.duration)
      }
    }
    const handleEnded = () => {
      if (currentTrack !== null && tracks.length > 0) {
        const nextTrack = (currentTrack + 1) % tracks.length
        setCurrentTrack(nextTrack)
        setTimeout(() => {
          if (audioRef.current) {
            audioRef.current.play().catch((e) => console.error("Error playing next track:", e))
          }
        }, 300)
      } else {
        setIsPlaying(false)
      }
    }

    audio.addEventListener("timeupdate", updateTime)
    audio.addEventListener("loadedmetadata", updateDuration)
    audio.addEventListener("ended", handleEnded)
    audio.volume = volume / 100

    return () => {
      audio.removeEventListener("timeupdate", updateTime)
      audio.removeEventListener("loadedmetadata", updateDuration)
      audio.removeEventListener("ended", handleEnded)
    }
  }, [currentTrack, tracks, volume])

  // Update audio source when current track changes
  useEffect(() => {
    if (currentTrack !== null && tracks[currentTrack]) {
      const audio = audioRef.current
      if (audio) {
        audio.src = tracks[currentTrack].url
        if (isPlaying) {
          audio.play().catch((e) => console.error("Error playing track:", e))
        }
      }
    }
  }, [currentTrack, tracks])

  // Generate a random color for the track
  const getRandomColor = () => {
    const colors = [
      "from-pink-500 to-purple-500",
      "from-blue-500 to-cyan-500",
      "from-green-500 to-emerald-500",
      "from-yellow-500 to-amber-500",
      "from-red-500 to-rose-500",
      "from-indigo-500 to-violet-500",
      "from-orange-500 to-red-500",
      "from-teal-500 to-green-500",
      "from-fuchsia-500 to-pink-500",
      "from-sky-500 to-blue-500",
    ]
    return colors[Math.floor(Math.random() * colors.length)]
  }

  // Extract metadata from audio file
  const extractMetadata = async (file: File): Promise<{ title: string; artist: string | null }> => {
    return new Promise((resolve) => {
      // Try to extract title from filename
      let title = file.name.replace(/\.[^/.]+$/, "") // Remove extension
      let artist = null

      // Check if filename has format "Artist - Title"
      const match = title.match(/^(.*?)\s*-\s*(.*)$/)
      if (match) {
        artist = match[1].trim()
        title = match[2].trim()
      }

      resolve({ title, artist })
    })
  }

  // Handle file upload
  const handleFileUpload = async (files: FileList | null) => {
    if (!files) return

    const newTracks: UserTrack[] = []

    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      if (file.type.startsWith("audio/")) {
        const url = URL.createObjectURL(file)
        const { title, artist } = await extractMetadata(file)

        newTracks.push({
          id: `track-${Date.now()}-${i}`,
          title,
          artist,
          url,
          duration: 0, // Will be updated when audio loads
          color: getRandomColor(),
        })
      }
    }

    if (newTracks.length > 0) {
      setTracks((prev) => [...prev, ...newTracks])
      if (currentTrack === null) {
        setCurrentTrack(0)
      }
    }
  }

  // Handle drag and drop
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files)
    }
  }

  // Toggle play/pause
  const togglePlay = () => {
    const audio = audioRef.current
    if (!audio) return

    if (currentTrack === null && tracks.length > 0) {
      setCurrentTrack(0)
      setIsPlaying(true)
      setTimeout(() => {
        if (audioRef.current) {
          audioRef.current.play().catch((e) => console.error("Error playing track:", e))
        }
      }, 100)
      return
    }

    if (isPlaying) {
      audio.pause()
    } else {
      audio.play().catch((e) => console.error("Error playing track:", e))
    }
    setIsPlaying(!isPlaying)
  }

  // Skip to next track
  const nextTrack = () => {
    if (tracks.length === 0 || currentTrack === null) return
    const next = (currentTrack + 1) % tracks.length
    setCurrentTrack(next)
  }

  // Skip to previous track
  const prevTrack = () => {
    if (tracks.length === 0 || currentTrack === null) return
    const prev = (currentTrack - 1 + tracks.length) % tracks.length
    setCurrentTrack(prev)
  }

  // Toggle mute
  const toggleMute = () => {
    const audio = audioRef.current
    if (audio) {
      audio.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    setVolume(newVolume)
    if (audioRef.current) {
      audioRef.current.volume = newVolume / 100
    }
  }

  // Format time (seconds to MM:SS)
  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return "0:00"
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  // Delete a track
  const deleteTrack = (id: string) => {
    const index = tracks.findIndex((t) => t.id === id)
    if (index === -1) return

    // Revoke object URL to prevent memory leaks
    URL.revokeObjectURL(tracks[index].url)

    // Update tracks
    const newTracks = tracks.filter((t) => t.id !== id)
    setTracks(newTracks)

    // Handle current track deletion
    if (currentTrack !== null) {
      if (index === currentTrack) {
        // If we're deleting the current track
        if (newTracks.length === 0) {
          // No more tracks
          setCurrentTrack(null)
          setIsPlaying(false)
        } else if (index >= newTracks.length) {
          // If we're deleting the last track, go to the new last track
          setCurrentTrack(newTracks.length - 1)
        }
        // Otherwise keep the same index (it will point to the next track)
      } else if (index < currentTrack) {
        // If we're deleting a track before the current one, adjust the index
        setCurrentTrack(currentTrack - 1)
      }
    }
  }

  // Calculate progress percentage
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0

  // Get current track info
  const currentTrackInfo = currentTrack !== null && tracks[currentTrack] ? tracks[currentTrack] : null

  return (
    <Card
      className={cn(
        "themed-card overflow-hidden transition-all duration-500",
        dragActive && "border-dashed border-4 bg-opacity-50 scale-[1.02]",
      )}
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
    >
      {/* Hidden audio element */}
      <audio ref={audioRef} />

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*"
        multiple
        onChange={(e) => handleFileUpload(e.target.files)}
        className="hidden"
      />

      {/* Music player header */}
      <div
        className={cn(
          "p-6 pb-4 transition-all duration-500",
          currentTrackInfo
            ? `bg-gradient-to-r ${currentTrackInfo.color}`
            : "bg-gradient-to-r from-gray-700 to-gray-900",
        )}
      >
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-2xl font-bold text-white">Your Music</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            className="bg-white/20 border-white/40 text-white hover:bg-white/30"
          >
            <Upload className="h-4 w-4 mr-2" />
            Add Music
          </Button>
        </div>

        {/* Current track display */}
        <div className="flex items-center space-x-4">
          <div
            className={cn(
              "w-16 h-16 rounded-full flex items-center justify-center bg-white/20 text-white transition-all duration-500",
              isPlaying && "animate-spin-slow",
            )}
          >
            <Music className="h-8 w-8" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-xl font-bold text-white truncate">
              {currentTrackInfo ? currentTrackInfo.title : "No track selected"}
            </h4>
            <p className="text-sm text-white/80 truncate">
              {currentTrackInfo && currentTrackInfo.artist ? currentTrackInfo.artist : "Upload your music to begin"}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-4">
          <div className="w-full bg-white/20 rounded-full h-1.5">
            <div
              className="h-1.5 rounded-full bg-white transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-white/80 mt-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="p-6 pt-4">
        <div className="flex items-center justify-center space-x-4 mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={prevTrack}
            disabled={tracks.length === 0 || currentTrack === null}
            className="themed-button-ghost"
          >
            <SkipBack className="h-5 w-5" />
          </Button>

          <Button
            onClick={togglePlay}
            disabled={tracks.length === 0}
            className="w-12 h-12 rounded-full themed-button-primary"
          >
            {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={nextTrack}
            disabled={tracks.length === 0 || currentTrack === null}
            className="themed-button-ghost"
          >
            <SkipForward className="h-5 w-5" />
          </Button>
        </div>

        {/* Volume control */}
        <div className="flex items-center space-x-3 mb-6">
          <Button variant="ghost" size="sm" onClick={toggleMute} className="themed-button-ghost">
            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
          <Slider
            value={[isMuted ? 0 : volume]}
            onValueChange={handleVolumeChange}
            max={100}
            step={1}
            className="flex-1"
          />
          <span className="text-xs w-8 themed-text">{isMuted ? 0 : volume}</span>
        </div>

        {/* Upload tip or track list */}
        {showUploadTip ? (
          <div className="text-center p-8 themed-card-inner rounded-lg">
            <Music className="h-12 w-12 mx-auto mb-4 themed-text-secondary opacity-50" />
            <h4 className="text-lg font-medium mb-2 themed-text">Your music library is empty</h4>
            <p className="text-sm mb-4 themed-text-secondary">
              Upload your favorite study music or drag and drop audio files here
            </p>
            <Button onClick={() => fileInputRef.current?.click()} className="themed-button">
              <Upload className="h-4 w-4 mr-2" />
              Upload Music
            </Button>
          </div>
        ) : (
          <div className="max-h-64 overflow-y-auto">
            <h5 className="text-sm font-semibold mb-3 themed-text">Your Music Library</h5>
            <div className="space-y-2">
              {tracks.map((track, index) => (
                <div
                  key={track.id}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-lg transition-all duration-200",
                    index === currentTrack ? "bg-gradient-to-r themed-track-active" : "themed-track hover:scale-[1.01]",
                  )}
                >
                  <button
                    onClick={() => {
                      setCurrentTrack(index)
                      if (!isPlaying) {
                        setIsPlaying(true)
                        setTimeout(() => {
                          if (audioRef.current) {
                            audioRef.current.play().catch((e) => console.error("Error playing track:", e))
                          }
                        }, 100)
                      }
                    }}
                    className="flex-1 text-left flex items-center min-w-0"
                  >
                    <div
                      className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center mr-3",
                        `bg-gradient-to-r ${track.color}`,
                      )}
                    >
                      {index === currentTrack && isPlaying ? (
                        <div className="flex space-x-0.5">
                          <div className="w-1 h-3 bg-white animate-music-bar-1"></div>
                          <div className="w-1 h-3 bg-white animate-music-bar-2"></div>
                          <div className="w-1 h-3 bg-white animate-music-bar-3"></div>
                        </div>
                      ) : (
                        <Music className="h-4 w-4 text-white" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="font-medium truncate themed-text">{track.title}</div>
                      {track.artist && <div className="text-xs themed-text-secondary truncate">{track.artist}</div>}
                    </div>
                  </button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteTrack(track.id)}
                    className="themed-button-ghost-danger ml-2"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Card>
  )
}
