"use client"

import { useState, useEffect, useRef } from "react"
import { Play, Pause, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface PomodoroTimerProps {
  onBreakChange: (isOnBreak: boolean) => void
}

export function PomodoroTimer({ onBreakChange }: PomodoroTimerProps) {
  const [timeLeft, setTimeLeft] = useState(25 * 60) // 25 minutes in seconds
  const [isRunning, setIsRunning] = useState(false)
  const [isBreak, setIsBreak] = useState(false)
  const [cycle, setCycle] = useState(1)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  const workTime = 25 * 60 // 25 minutes
  const shortBreak = 5 * 60 // 5 minutes
  const longBreak = 15 * 60 // 15 minutes

  useEffect(() => {
    onBreakChange(isBreak)
  }, [isBreak, onBreakChange])

  useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      // Timer finished
      setIsRunning(false)

      if (isBreak) {
        // Break finished, start work session
        setIsBreak(false)
        setTimeLeft(workTime)
        setCycle((prev) => prev + 1)
        showNotification("Break time is over! Ready to focus?")
      } else {
        // Work session finished, start break
        setIsBreak(true)
        const isLongBreak = cycle % 4 === 0
        setTimeLeft(isLongBreak ? longBreak : shortBreak)
        showNotification(isLongBreak ? "Great work! Time for a long break!" : "Well done! Time for a short break!")
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isRunning, timeLeft, isBreak, cycle, workTime, shortBreak, longBreak])

  const showNotification = (message: string) => {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("Study Buddy", { body: message })
    }
  }

  const requestNotificationPermission = () => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission()
    }
  }

  const toggleTimer = () => {
    if (!isRunning) {
      requestNotificationPermission()
    }
    setIsRunning(!isRunning)
  }

  const resetTimer = () => {
    setIsRunning(false)
    setIsBreak(false)
    setTimeLeft(workTime)
    setCycle(1)
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
    }
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const progress = isBreak
    ? ((cycle % 4 === 0 ? longBreak : shortBreak) - timeLeft) / (cycle % 4 === 0 ? longBreak : shortBreak)
    : (workTime - timeLeft) / workTime

  return (
    <Card className="p-6 bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-950/50 dark:to-orange-950/50 border-red-200 dark:border-red-800">
      <div className="text-center">
        <div className="mb-4">
          <h3 className="text-lg font-semibold text-red-900 dark:text-red-100 mb-2">Pomodoro Timer</h3>
          <div
            className={cn(
              "text-sm font-medium px-3 py-1 rounded-full inline-block",
              isBreak
                ? "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200"
                : "bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200",
            )}
          >
            {isBreak ? (cycle % 4 === 0 ? "Long Break" : "Short Break") : `Focus Session ${cycle}`}
          </div>
        </div>

        <div className="mb-6">
          <div className="text-6xl font-mono font-bold text-red-900 dark:text-red-100 mb-4">{formatTime(timeLeft)}</div>

          {/* Progress Bar */}
          <div className="w-full bg-red-200 dark:bg-red-800 rounded-full h-2 mb-4">
            <div
              className={cn("h-2 rounded-full transition-all duration-1000", isBreak ? "bg-green-500" : "bg-red-500")}
              style={{ width: `${progress * 100}%` }}
            />
          </div>
        </div>

        <div className="flex justify-center space-x-4">
          <Button
            onClick={toggleTimer}
            className={cn(
              "px-6 py-2",
              isRunning ? "bg-red-600 hover:bg-red-700 text-white" : "bg-green-600 hover:bg-green-700 text-white",
            )}
          >
            {isRunning ? (
              <>
                <Pause className="h-4 w-4 mr-2" />
                Pause
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Start
              </>
            )}
          </Button>

          <Button onClick={resetTimer} variant="outline" className="px-6 py-2 border-red-300 dark:border-red-700">
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset
          </Button>
        </div>

        {isBreak && (
          <div className="mt-4 p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
            <p className="text-sm text-green-800 dark:text-green-200">
              🌱 Break time! Your plant and chatbot are ready to interact!
            </p>
          </div>
        )}
      </div>
    </Card>
  )
}
