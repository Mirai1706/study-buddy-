"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, Volume2, VolumeX, SkipForward, SkipBack, Upload, X, Music } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface CustomTrack {
  id: string
  title: string
  file: File
  url: string
  duration: number
}

const defaultTracks = [
  { id: "default-1", title: "Forest Rain", artist: "Nature Sounds", duration: "10:00", genre: "Ambient" },
  { id: "default-2", title: "Coffee Shop Jazz", artist: "Study Beats", duration: "8:30", genre: "Jazz" },
  { id: "default-3", title: "Ocean Waves", artist: "Relaxation", duration: "12:00", genre: "Nature" },
  { id: "default-4", title: "Piano Focus", artist: "Classical Study", duration: "6:45", genre: "Classical" },
  { id: "default-5", title: "White Noise", artist: "Concentration", duration: "15:00", genre: "Ambient" },
  { id: "default-6", title: "Lofi Hip Hop", artist: "Chill Beats", duration: "7:20", genre: "Lofi" },
]

export function CustomMusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTrack, setCurrentTrack] = useState(0)
  const [volume, setVolume] = useState([70])
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [customTracks, setCustomTracks] = useState<CustomTrack[]>([])
  const [isUsingCustom, setIsUsingCustom] = useState(false)
  const [showUpload, setShowUpload] = useState(false)

  const audioRef = useRef<HTMLAudioElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Load custom tracks from localStorage
  useEffect(() => {
    const savedTracks = localStorage.getItem("study-buddy-custom-tracks")
    if (savedTracks) {
      try {
        const tracks = JSON.parse(savedTracks)
        setCustomTracks(tracks)
      } catch (error) {
        console.error("Error loading custom tracks:", error)
      }
    }
  }, [])

  // Save custom tracks to localStorage
  useEffect(() => {
    if (customTracks.length > 0) {
      const tracksToSave = customTracks.map((track) => ({
        id: track.id,
        title: track.title,
        url: track.url,
        duration: track.duration,
      }))
      localStorage.setItem("study-buddy-custom-tracks", JSON.stringify(tracksToSave))
    }
  }, [customTracks])

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const updateTime = () => setCurrentTime(audio.currentTime)
    const updateDuration = () => setDuration(audio.duration)
    const handleEnded = () => {
      setIsPlaying(false)
      nextTrack()
    }

    audio.addEventListener("timeupdate", updateTime)
    audio.addEventListener("loadedmetadata", updateDuration)
    audio.addEventListener("ended", handleEnded)

    return () => {
      audio.removeEventListener("timeupdate", updateTime)
      audio.removeEventListener("loadedmetadata", updateDuration)
      audio.removeEventListener("ended", handleEnded)
    }
  }, [])

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files) return

    Array.from(files).forEach((file) => {
      if (file.type.startsWith("audio/")) {
        const url = URL.createObjectURL(file)
        const newTrack: CustomTrack = {
          id: Date.now().toString() + Math.random(),
          title: file.name.replace(/\.[^/.]+$/, ""), // Remove file extension
          file,
          url,
          duration: 0,
        }

        setCustomTracks((prev) => [...prev, newTrack])
      }
    })

    // Clear the input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
    setShowUpload(false)
  }

  // Remove custom track
  const removeCustomTrack = (trackId: string) => {
    setCustomTracks((prev) => {
      const track = prev.find((t) => t.id === trackId)
      if (track) {
        URL.revokeObjectURL(track.url)
      }
      return prev.filter((t) => t.id !== trackId)
    })
  }

  const togglePlay = () => {
    const audio = audioRef.current
    if (!audio) return

    if (isPlaying) {
      audio.pause()
    } else {
      // Load current track if using custom tracks
      if (isUsingCustom && customTracks[currentTrack]) {
        audio.src = customTracks[currentTrack].url
      }
      audio.play()
    }
    setIsPlaying(!isPlaying)
  }

  const nextTrack = () => {
    const trackList = isUsingCustom ? customTracks : defaultTracks
    setCurrentTrack((prev) => (prev + 1) % trackList.length)
    setCurrentTime(0)
  }

  const previousTrack = () => {
    const trackList = isUsingCustom ? customTracks : defaultTracks
    setCurrentTrack((prev) => (prev - 1 + trackList.length) % trackList.length)
    setCurrentTime(0)
  }

  const toggleMute = () => {
    const audio = audioRef.current
    if (audio) {
      audio.muted = !isMuted
    }
    setIsMuted(!isMuted)
  }

  const handleVolumeChange = (value: number[]) => {
    setVolume(value)
    const audio = audioRef.current
    if (audio) {
      audio.volume = value[0] / 100
    }
  }

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return "0:00"
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getCurrentTrack = () => {
    if (isUsingCustom) {
      return customTracks[currentTrack] || null
    }
    return defaultTracks[currentTrack] || null
  }

  const currentTrackData = getCurrentTrack()
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0

  return (
    <Card className="p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-2xl font-bold">Study Music</h3>
          <div className="flex gap-2">
            <Button variant={isUsingCustom ? "outline" : "default"} size="sm" onClick={() => setIsUsingCustom(false)}>
              Default
            </Button>
            <Button
              variant={isUsingCustom ? "default" : "outline"}
              size="sm"
              onClick={() => setIsUsingCustom(true)}
              disabled={customTracks.length === 0}
            >
              My Music ({customTracks.length})
            </Button>
          </div>
        </div>

        {/* Upload Section */}
        {isUsingCustom && (
          <div className="mb-4">
            {!showUpload ? (
              <Button onClick={() => setShowUpload(true)} className="w-full mb-2" variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Upload Music Files
              </Button>
            ) : (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 mb-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="audio/*"
                  multiple
                  onChange={handleFileUpload}
                  className="w-full mb-2"
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => fileInputRef.current?.click()}>
                    Choose Files
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setShowUpload(false)}>
                    Cancel
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2">Supported formats: MP3, WAV, OGG, M4A</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Current Track Display */}
      {currentTrackData && (
        <div className="mb-6 text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg">
            <Music className="text-2xl text-white" />
          </div>
          <h4 className="font-semibold mb-1">{isUsingCustom ? currentTrackData.title : currentTrackData.title}</h4>
          {!isUsingCustom && (
            <>
              <p className="text-sm text-gray-600">{currentTrackData.artist}</p>
              <span className="inline-block px-2 py-1 text-xs bg-purple-500/20 text-purple-600 rounded-full mt-2">
                {currentTrackData.genre}
              </span>
            </>
          )}
        </div>
      )}

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
          <div
            className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-gray-500">
          <span>{formatTime(currentTime)}</span>
          <span>{isUsingCustom ? formatTime(duration) : currentTrackData?.duration || "0:00"}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center space-x-4 mb-6">
        <Button variant="ghost" size="sm" onClick={previousTrack}>
          <SkipBack className="h-5 w-5" />
        </Button>

        <Button
          onClick={togglePlay}
          className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white"
          disabled={!currentTrackData}
        >
          {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
        </Button>

        <Button variant="ghost" size="sm" onClick={nextTrack}>
          <SkipForward className="h-5 w-5" />
        </Button>
      </div>

      {/* Volume Control */}
      <div className="flex items-center space-x-3 mb-6">
        <Button variant="ghost" size="sm" onClick={toggleMute}>
          {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>
        <Slider
          value={isMuted ? [0] : volume}
          onValueChange={handleVolumeChange}
          max={100}
          step={1}
          className="flex-1"
        />
        <span className="text-xs w-8">{isMuted ? 0 : volume[0]}</span>
      </div>

      {/* Track List */}
      <div className="max-h-32 overflow-y-auto">
        <h5 className="text-sm font-semibold mb-3">{isUsingCustom ? "My Playlist" : "Default Playlist"}</h5>
        <div className="space-y-2">
          {(isUsingCustom ? customTracks : defaultTracks).map((track, index) => (
            <div
              key={track.id}
              className={cn(
                "flex items-center justify-between p-2 rounded-lg transition-all duration-200 text-xs",
                index === currentTrack ? "bg-purple-500/20 text-purple-600" : "hover:bg-gray-100 text-gray-600",
              )}
            >
              <button
                onClick={() => {
                  setCurrentTrack(index)
                  setCurrentTime(0)
                }}
                className="flex-1 text-left"
              >
                <div className="font-medium">{track.title}</div>
                {!isUsingCustom && (
                  <div className="opacity-70">
                    {track.artist} • {track.genre}
                  </div>
                )}
              </button>
              {isUsingCustom && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeCustomTrack(track.id)}
                  className="text-red-500 hover:text-red-700"
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Hidden audio element */}
      <audio ref={audioRef} />
    </Card>
  )
}
