"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

interface VirtualPlantProps {
  completedTasks: number
  totalTasks: number
  isAllCompleted: boolean
}

export function VirtualPlant({ completedTasks, totalTasks, isAllCompleted }: VirtualPlantProps) {
  const [plantStage, setPlantStage] = useState(0)
  const [showFruit, setShowFruit] = useState(false)

  useEffect(() => {
    if (totalTasks === 0) {
      setPlantStage(0)
      setShowFruit(false)
      return
    }

    const progress = completedTasks / totalTasks

    if (progress === 0) {
      setPlantStage(0) // Seed
    } else if (progress < 0.5) {
      setPlantStage(1) // Sprout
    } else if (progress < 1) {
      setPlantStage(2) // Growing
    } else {
      setPlantStage(3) // Full grown
      if (isAllCompleted) {
        setShowFruit(true)
      }
    }
  }, [completedTasks, totalTasks, isAllCompleted])

  const getPlantEmoji = () => {
    switch (plantStage) {
      case 0:
        return "🌱" // Seed
      case 1:
        return "🌿" // Sprout
      case 2:
        return "🌳" // Growing tree
      case 3:
        return showFruit ? "🌳🍎" : "🌳" // Full tree with fruit
      default:
        return "🌱"
    }
  }

  const getPlantMessage = () => {
    switch (plantStage) {
      case 0:
        return totalTasks === 0
          ? "Plant a seed by adding your first task!"
          : "Your study seed is planted! Complete tasks to help it grow."
      case 1:
        return "Great start! Your plant is sprouting. Keep going!"
      case 2:
        return "Wonderful progress! Your plant is growing strong."
      case 3:
        return showFruit
          ? "🎉 Amazing! Your plant has grown fruit! You've completed all tasks today!"
          : "Almost there! Your plant is fully grown. Complete all tasks for a special reward!"
      default:
        return "Keep studying to grow your plant!"
    }
  }

  const getProgressColor = () => {
    if (totalTasks === 0) return "from-gray-400 to-gray-500"
    const progress = completedTasks / totalTasks
    if (progress < 0.3) return "from-red-400 to-red-500"
    if (progress < 0.7) return "from-yellow-400 to-orange-500"
    return "from-green-400 to-emerald-500"
  }

  return (
    <div>
      <h3 className="text-2xl font-bold text-elegant gradient-text mb-6">Your Study Plant</h3>

      <div className="text-center">
        {/* Plant Display */}
        <div className="mb-8 plant-container">
          <div className="plant-glow"></div>
          <div className="text-8xl mb-6 float-animation relative z-10">{getPlantEmoji()}</div>

          {/* Growth Progress Bar */}
          <div className="progress-elegant h-4 mb-6">
            <div
              className={cn("progress-fill bg-gradient-to-r", getProgressColor())}
              style={{
                width: totalTasks === 0 ? "0%" : `${(completedTasks / totalTasks) * 100}%`,
              }}
            />
          </div>

          <div className="text-lg font-semibold text-muted-elegant mb-4">
            Growth: {totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100)}%
          </div>
        </div>

        {/* Plant Message */}
        <div
          className={cn(
            "p-6 rounded-2xl text-sm font-medium glass mb-6",
            showFruit
              ? "bg-gradient-to-r from-green-500/20 to-emerald-500/20 border-green-400/30"
              : "bg-gradient-to-r from-blue-500/20 to-purple-500/20 border-blue-400/30",
          )}
        >
          {getPlantMessage()}
        </div>

        {/* Plant Care Tips */}
        <div className="glass p-5 rounded-2xl mb-6">
          <h4 className="font-bold text-elegant mb-4 text-lg">🌿 Plant Care Tips</h4>
          <div className="text-sm text-muted-elegant space-y-2">
            <div className="flex items-center space-x-2">
              <span>🌱</span>
              <span>Complete tasks daily to keep your plant healthy</span>
            </div>
            <div className="flex items-center space-x-2">
              <span>💧</span>
              <span>Consistent progress helps your plant grow faster</span>
            </div>
            <div className="flex items-center space-x-2">
              <span>🍎</span>
              <span>Finish all daily tasks to harvest fruit rewards!</span>
            </div>
          </div>
        </div>

        {/* Achievement Display */}
        {showFruit && (
          <div className="glass p-6 rounded-2xl bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-400/30 animate-pulse">
            <div className="text-4xl mb-3">🏆</div>
            <div className="font-bold text-elegant text-lg mb-2">Daily Achievement Unlocked!</div>
            <div className="text-sm text-muted-elegant">You've completed all tasks today!</div>
          </div>
        )}
      </div>
    </div>
  )
}
