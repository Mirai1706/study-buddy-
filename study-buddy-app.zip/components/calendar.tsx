"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface CalendarProps {
  selectedDate: Date
  onDateSelect: (date: Date) => void
  tasks: Record<string, any[]>
}

export function Calendar({ selectedDate, onDateSelect, tasks }: CalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date())

  const today = new Date()
  today.setHours(0, 0, 0, 0) // Reset time for accurate comparison

  const year = currentMonth.getFullYear()
  const month = currentMonth.getMonth()

  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)
  const firstDayWeekday = firstDayOfMonth.getDay()
  const daysInMonth = lastDayOfMonth.getDate()

  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  const previousMonth = () => {
    setCurrentMonth(new Date(year, month - 1, 1))
  }

  const nextMonth = () => {
    setCurrentMonth(new Date(year, month + 1, 1))
  }

  const getTasksForDate = (date: Date) => {
    const dateKey = date.toDateString()
    return Array.isArray(tasks[dateKey]) ? tasks[dateKey] : []
  }

  const getTaskProgress = (date: Date) => {
    const dateTasks = getTasksForDate(date)
    if (dateTasks.length === 0) return null

    const completed = dateTasks.filter((task) => task && task.completed).length
    const incomplete = dateTasks.length - completed

    return { completed, incomplete, total: dateTasks.length }
  }

  const handleDateClick = (date: Date) => {
    console.log("Date clicked:", date) // Debug log
    onDateSelect(new Date(date))
  }

  const renderCalendarDays = () => {
    const days = []

    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDayWeekday; i++) {
      days.push(<div key={`empty-${i}`} className="h-14" />)
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day)
      date.setHours(0, 0, 0, 0) // Reset time for accurate comparison

      const isToday = date.toDateString() === today.toDateString()
      const isSelected = date.toDateString() === selectedDate.toDateString()
      const progress = getTaskProgress(date)

      days.push(
        <button
          key={day}
          onClick={(e) => {
            e.preventDefault()
            handleDateClick(date)
          }}
          className={cn(
            "calendar-day h-14 w-full rounded-xl text-sm font-medium transition-all duration-300 relative glass",
            "hover:scale-105 hover:shadow-lg cursor-pointer",
            isToday && "today ring-2 ring-blue-400",
            isSelected && "selected ring-2 ring-amber-400",
            !isToday && !isSelected && "text-elegant hover:bg-white/10",
          )}
        >
          <span className="relative z-10">{day}</span>
          {progress && (
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 z-10">
              <div className="flex space-x-1">
                {/* Completed tasks indicators */}
                {progress.completed > 0 && (
                  <div
                    className="h-2 rounded-full bg-green-400 shadow-lg shadow-green-400/50"
                    style={{ width: `${Math.min(progress.completed * 6, 18)}px` }}
                  />
                )}

                {/* Incomplete tasks indicators */}
                {progress.incomplete > 0 && (
                  <div
                    className="h-2 rounded-full bg-amber-400 shadow-lg shadow-amber-400/50"
                    style={{ width: `${Math.min(progress.incomplete * 6, 18)}px` }}
                  />
                )}

                {/* Show count if many tasks */}
                {progress.total > 5 && <div className="text-xs text-elegant font-bold">+{progress.total - 5}</div>}
              </div>
            </div>
          )}
        </button>,
      )
    }

    return days
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-elegant gradient-text">
          {monthNames[month]} {year}
        </h2>
        <div className="flex space-x-3">
          <Button variant="outline" size="sm" onClick={previousMonth} className="btn-elegant">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={nextMonth} className="btn-elegant">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-2 mb-4">
        {weekDays.map((day) => (
          <div key={day} className="h-10 flex items-center justify-center text-sm font-semibold text-muted-elegant">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">{renderCalendarDays()}</div>

      <div className="mt-6 flex justify-center space-x-6">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-green-400"></div>
          <span className="text-xs text-muted-elegant">Completed</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-amber-400"></div>
          <span className="text-xs text-muted-elegant">Remaining</span>
        </div>
      </div>
    </div>
  )
}
