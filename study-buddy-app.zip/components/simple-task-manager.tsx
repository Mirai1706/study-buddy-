"use client"

import type React from "react"

import { useState } from "react"
import type { Task } from "@/app/page"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface SimpleTaskManagerProps {
  selectedDate: Date
  tasks: Task[]
  onTasksUpdate: (tasks: Task[]) => void
  formatDisplayDate: (date: Date) => string
}

export function SimpleTaskManager({ selectedDate, tasks, onTasksUpdate, formatDisplayDate }: SimpleTaskManagerProps) {
  const [newTaskText, setNewTaskText] = useState("")

  // Add a new task
  const addTask = () => {
    if (newTaskText.trim()) {
      const newTask: Task = {
        id: Date.now().toString(),
        text: newTaskText.trim(),
        completed: false,
        timeSpent: 0,
      }
      onTasksUpdate([...tasks, newTask])
      setNewTaskText("")
    }
  }

  // Toggle task completion
  const toggleTask = (id: string) => {
    const updatedTasks = tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task))
    onTasksUpdate(updatedTasks)
  }

  // Delete a task
  const deleteTask = (id: string) => {
    const updatedTasks = tasks.filter((task) => task.id !== id)
    onTasksUpdate(updatedTasks)
  }

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      addTask()
    }
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4 themed-text">Tasks for {formatDisplayDate(selectedDate)}</h2>

      {/* Add task input */}
      <div className="flex gap-2 mb-6">
        <Input
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Add a new task..."
          className="flex-1 themed-input"
        />
        <Button onClick={addTask} className="themed-button">
          Add
        </Button>
      </div>

      {/* Task list */}
      <div className="space-y-2">
        {tasks.length === 0 ? (
          <div className="text-center py-8 themed-card-inner rounded-lg">
            <p className="themed-text-secondary">No tasks for this day. Add one to get started!</p>
          </div>
        ) : (
          tasks.map((task) => (
            <div
              key={task.id}
              className={`p-3 rounded-lg flex items-center gap-3 transition-all duration-200 hover:scale-[1.02] ${
                task.completed ? "themed-task-completed" : "themed-task-pending"
              }`}
            >
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => toggleTask(task.id)}
                className="w-5 h-5 themed-checkbox"
              />
              <span className={task.completed ? "line-through themed-text-secondary flex-1" : "themed-text flex-1"}>
                {task.text}
              </span>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => deleteTask(task.id)}
                className="themed-button-danger"
              >
                Delete
              </Button>
            </div>
          ))
        )}
      </div>

      {/* Summary */}
      {tasks.length > 0 && (
        <div className="mt-6 p-3 themed-card-inner rounded-lg">
          <div className="text-sm themed-text-secondary space-y-1">
            <p>
              Completed: <span className="font-bold themed-text">{tasks.filter((t) => t.completed).length}</span> /{" "}
              <span className="font-bold themed-text">{tasks.length}</span>
            </p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div
                className="themed-progress-bar h-2 rounded-full transition-all duration-300"
                style={{
                  width: `${tasks.length > 0 ? (tasks.filter((t) => t.completed).length / tasks.length) * 100 : 0}%`,
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
