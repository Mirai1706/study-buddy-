"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, Bot, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  text: string
  isBot: boolean
  timestamp: Date
}

interface StudyChatbotProps {
  isOnBreak: boolean
}

export function StudyChatbot({ isOnBreak }: StudyChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hi there! I'm your Study Buddy assistant. I'm here to chat, motivate you, and help with your studies. How are you feeling today?",
      isBot: true,
      timestamp: new Date(),
    },
  ])
  const [inputText, setInputText] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  const motivationalQuotes = [
    "The expert in anything was once a beginner. Keep going! 💪",
    "Success is the sum of small efforts repeated day in and day out. 🌟",
    "You're doing great! Every small step counts toward your goals. 🎯",
    "Remember: progress, not perfection. You've got this! ✨",
    "The best time to plant a tree was 20 years ago. The second best time is now! 🌳",
    "Your future self will thank you for the work you're doing today. 🚀",
    "Believe in yourself and all that you are. You're capable of amazing things! 💫",
  ]

  const studyTips = [
    "Try the Feynman Technique: explain concepts in simple terms as if teaching someone else! 🧠",
    "Take regular breaks every 25-30 minutes to maintain focus and avoid burnout. 🔄",
    "Create a dedicated study space free from distractions. Your environment matters! 🏠",
    "Use active recall: test yourself instead of just re-reading notes. 📝",
    "Break large tasks into smaller, manageable chunks. It makes everything less overwhelming! 📋",
    "Stay hydrated and eat brain-healthy snacks like nuts and fruits. 🥜🍎",
    "Get enough sleep! Your brain consolidates memories during rest. 😴",
  ]

  const breakActivities = [
    "Perfect break time! Try some light stretching or a quick walk. 🚶‍♀️",
    "How about some deep breathing exercises? 4 counts in, 4 counts out. 🧘‍♂️",
    "Grab a healthy snack and some water. Your brain needs fuel! 🥤",
    "Look away from your screen and focus on something far away for a minute. 👀",
    "Do some quick desk exercises: shoulder rolls, neck stretches, or arm circles. 💪",
    "Listen to your favorite song or do a quick dance! Movement boosts energy. 🎵",
  ]

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const generateBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase()

    // Greeting responses
    if (lowerMessage.includes("hello") || lowerMessage.includes("hi") || lowerMessage.includes("hey")) {
      return "Hello! It's great to chat with you. How's your day going? 😊"
    }

    // How are you responses
    if (lowerMessage.includes("how are you")) {
      return "I'm doing great, thanks for asking! I'm here to support your study journey. How about you? How are you feeling today? 💫"
    }

    // Name responses
    if (lowerMessage.includes("what's your name") || lowerMessage.includes("who are you")) {
      return "I'm your Study Buddy! I'm here to chat, motivate you, and help make your study sessions more enjoyable. Think of me as your friendly study companion! 📚"
    }

    // Motivation requests
    if (lowerMessage.includes("motivat") || lowerMessage.includes("encourage") || lowerMessage.includes("inspire")) {
      return motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)]
    }

    // Study tips
    if (
      lowerMessage.includes("tip") ||
      lowerMessage.includes("advice") ||
      lowerMessage.includes("help") ||
      lowerMessage.includes("study")
    ) {
      return studyTips[Math.floor(Math.random() * studyTips.length)]
    }

    // Break time responses
    if (isOnBreak || lowerMessage.includes("break") || lowerMessage.includes("rest")) {
      return breakActivities[Math.floor(Math.random() * breakActivities.length)]
    }

    // Feeling responses
    if (lowerMessage.includes("tired") || lowerMessage.includes("exhausted")) {
      return "I understand you're feeling tired. Remember, it's okay to take breaks! Try a 5-minute walk or some deep breathing. You're doing better than you think! 💙"
    }

    if (lowerMessage.includes("stressed") || lowerMessage.includes("overwhelmed")) {
      return "Feeling overwhelmed is normal when studying. Try breaking your tasks into smaller pieces, and remember - you don't have to do everything at once. One step at a time! 🌈"
    }

    if (lowerMessage.includes("proud") || lowerMessage.includes("accomplished") || lowerMessage.includes("finished")) {
      return "That's fantastic! I'm so proud of your progress. Celebrating small wins is important - you're building great study habits! 🎉"
    }

    // Focus issues
    if (lowerMessage.includes("focus") || lowerMessage.includes("concentrate") || lowerMessage.includes("distracted")) {
      return "Having trouble focusing? Try the Pomodoro technique, remove distractions, and make sure you're in a comfortable environment. You've got this! 🎯"
    }

    // Subject-specific responses
    if (lowerMessage.includes("math") || lowerMessage.includes("mathematics")) {
      return "Math can be challenging but also rewarding! Try working through problems step-by-step and don't be afraid to look for different explanations online. Practice is key with math! 🔢"
    }

    if (
      lowerMessage.includes("science") ||
      lowerMessage.includes("biology") ||
      lowerMessage.includes("chemistry") ||
      lowerMessage.includes("physics")
    ) {
      return "Science is all about curiosity! Try connecting concepts to real-world examples, and don't hesitate to draw diagrams to visualize complex processes. YouTube has great science explainers too! 🧪"
    }

    if (lowerMessage.includes("history") || lowerMessage.includes("geography")) {
      return "For subjects like history, try creating timelines or mind maps to connect events. Associating facts with stories or images can make them much more memorable! 🗺️"
    }

    if (lowerMessage.includes("language") || lowerMessage.includes("english") || lowerMessage.includes("writing")) {
      return "With languages, regular practice is essential! Try reading articles, watching shows with subtitles, or even talking to yourself in that language. For writing, reading good examples can really help improve your style! ✍️"
    }

    // Time management
    if (lowerMessage.includes("time") || lowerMessage.includes("schedule") || lowerMessage.includes("plan")) {
      return "Good time management is crucial! Try planning your day the night before, prioritizing your most important tasks, and breaking study sessions into focused 25-minute blocks with short breaks in between. 🕒"
    }

    // Exam preparation
    if (lowerMessage.includes("exam") || lowerMessage.includes("test") || lowerMessage.includes("quiz")) {
      return "For exam prep, practice active recall by testing yourself rather than just re-reading notes. Create practice questions, use flashcards, and try explaining concepts out loud as if teaching someone else! 📝"
    }

    // Friendly chat
    if (lowerMessage.includes("favorite") || lowerMessage.includes("like") || lowerMessage.includes("enjoy")) {
      return "As your Study Buddy, I enjoy helping you learn and stay motivated! I'm here to support your unique learning journey and celebrate your progress along the way. What's your favorite subject to study? 🌟"
    }

    if (lowerMessage.includes("thank")) {
      return "You're very welcome! I'm always here to chat and support you. Remember, you're doing great work, and it's a privilege to be part of your learning journey! 💫"
    }

    if (lowerMessage.includes("joke") || lowerMessage.includes("funny")) {
      const jokes = [
        "Why don't scientists trust atoms? Because they make up everything! 😄",
        "What did one wall say to the other wall? I'll meet you at the corner! 😆",
        "Why did the scarecrow win an award? Because he was outstanding in his field! 🌾",
        "What do you call a fake noodle? An impasta! 🍝",
        "How does a penguin build its house? Igloos it together! 🐧",
      ]
      return jokes[Math.floor(Math.random() * jokes.length)]
    }

    // Default responses
    const defaultResponses = [
      "That's interesting! Tell me more about how your studying is going. What are you working on today? 🤔",
      "I'm here to support you! What would help you most right now - motivation, study tips, or just a friendly chat? 😊",
      "Every study session is a step forward. How are you feeling about your progress today? 📚",
      "I'd love to hear more about that! What subjects are you focusing on currently? 💬",
      "Remember, learning is a journey, not a destination. What's been your biggest challenge lately? 🌱",
    ]

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const sendMessage = () => {
    if (!inputText.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText.trim(),
      isBot: false,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputText("")
    setIsTyping(true)

    // Simulate bot typing delay
    setTimeout(
      () => {
        const botResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: generateBotResponse(inputText.trim()),
          isBot: true,
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, botResponse])
        setIsTyping(false)
      },
      1000 + Math.random() * 1000,
    ) // 1-2 second delay
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage()
    }
  }

  return (
    <div className="h-96 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-2xl font-bold text-elegant gradient-text">Study Buddy Chat</h3>
        {isOnBreak && (
          <div className="text-xs bg-green-500/20 text-green-400 px-3 py-1 rounded-full glass">Break Time Active</div>
        )}
      </div>

      <ScrollArea className="flex-1 mb-4 p-3 border rounded-lg glass" ref={scrollAreaRef}>
        <div className="space-y-3">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn("flex items-start space-x-2 chat-message", message.isBot ? "justify-start" : "justify-end")}
            >
              {message.isBot && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0 shadow-lg">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              <div
                className={cn(
                  "max-w-[80%] p-4 rounded-2xl text-sm",
                  message.isBot
                    ? "bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-400/30 text-elegant"
                    : "bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-400/30 text-elegant",
                )}
              >
                {message.text}
              </div>
              {!message.isBot && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center flex-shrink-0 shadow-lg">
                  <User className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex items-start space-x-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0 shadow-lg">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-400/30 p-4 rounded-2xl">
                <div className="loading-dots">
                  <div className="loading-dot"></div>
                  <div className="loading-dot"></div>
                  <div className="loading-dot"></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="flex space-x-2">
        <Input
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Chat with your study buddy..."
          className="flex-1 input-elegant"
          disabled={isTyping}
        />
        <Button
          onClick={sendMessage}
          disabled={!inputText.trim() || isTyping}
          className="btn-elegant bg-gradient-to-r from-blue-500 to-purple-500 text-white"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
