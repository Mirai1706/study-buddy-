"use client"

import { useState } from "react"
import { Palette, Check, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu"

interface CreativeThemeToggleProps {
  currentTheme: string
  onThemeChange: (theme: string) => void
}

export function CreativeThemeToggle({ currentTheme, onThemeChange }: CreativeThemeToggleProps) {
  const [isOpen, setIsOpen] = useState(false)

  const themeCategories = [
    {
      category: "✨ Aesthetic Vibes",
      themes: [
        { id: "aesthetic-pink", name: "Aesthetic Pink", colors: ["#fdf2f8", "#ec4899", "#be185d"], emoji: "🌸" },
        { id: "aesthetic-purple", name: "Aesthetic Purple", colors: ["#faf5ff", "#a855f7", "#7c3aed"], emoji: "💜" },
        { id: "lavender-dreams", name: "Lavender Dreams", colors: ["#f8fafc", "#a78bfa", "#8b5cf6"], emoji: "🌙" },
        { id: "rose-gold", name: "Rose Gold", colors: ["#fef7f0", "#ea580c", "#c2410c"], emoji: "🌹" },
      ],
    },
    {
      category: "🎯 Academia Classics",
      themes: [
        { id: "light-academia", name: "Light Academia", colors: ["#f8f5f0", "#8b7355", "#c19a6b"], emoji: "📚" },
        { id: "dark-academia", name: "Dark Academia", colors: ["#2c2418", "#c19a6b", "#d4b483"], emoji: "🕯️" },
        { id: "vintage-blue", name: "Vintage Blue", colors: ["#eff6ff", "#3b82f6", "#2563eb"], emoji: "📖" },
      ],
    },
    {
      category: "🌿 Nature Inspired",
      themes: [
        { id: "cottagecore", name: "Cottagecore", colors: ["#f0fdf4", "#65a30d", "#4d7c0f"], emoji: "🏡" },
        { id: "forest-green", name: "Forest Green", colors: ["#064e3b", "#10b981", "#34d399"], emoji: "🌲" },
        { id: "sage-green", name: "Sage Green", colors: ["#f6f7f6", "#68d391", "#38a169"], emoji: "🍃" },
        { id: "mint-fresh", name: "Mint Fresh", colors: ["#f0fdfa", "#14b8a6", "#0f766e"], emoji: "🌱" },
        { id: "ocean-blue", name: "Ocean Blue", colors: ["#0c4a6e", "#0ea5e9", "#38bdf8"], emoji: "🌊" },
      ],
    },
    {
      category: "✨ Chic & Modern",
      themes: [
        { id: "chic-minimal", name: "Chic Minimal", colors: ["#fafafa", "#525252", "#404040"], emoji: "⚪" },
        { id: "chic-gold", name: "Chic Gold", colors: ["#fffbeb", "#d97706", "#b45309"], emoji: "✨" },
        { id: "midnight-black", name: "Midnight Black", colors: ["#000000", "#64748b", "#94a3b8"], emoji: "🖤" },
        { id: "cream-beige", name: "Cream Beige", colors: ["#fefce8", "#ca8a04", "#a16207"], emoji: "🤎" },
      ],
    },
    {
      category: "🔥 Bold & Vibrant",
      themes: [
        { id: "cyberpunk", name: "Cyberpunk", colors: ["#0c0a09", "#00ff88", "#ff0080"], emoji: "🤖" },
        { id: "sunset-orange", name: "Sunset Orange", colors: ["#7c2d12", "#fb923c", "#fdba74"], emoji: "🧡" },
        { id: "dusty-rose", name: "Dusty Rose", colors: ["#fdf2f8", "#db2777", "#be185d"], emoji: "🌺" },
        { id: "coffee-brown", name: "Coffee Brown", colors: ["#451a03", "#d97706", "#fbbf24"], emoji: "☕" },
      ],
    },
  ]

  const getCurrentTheme = () => {
    for (const category of themeCategories) {
      const theme = category.themes.find((t) => t.id === currentTheme)
      if (theme) return theme
    }
    return themeCategories[0].themes[0]
  }

  const currentThemeData = getCurrentTheme()

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className="min-w-[200px] justify-between bg-white/10 backdrop-blur-sm border-2 hover:bg-white/20 transition-all duration-300"
        >
          <div className="flex items-center gap-2">
            <span className="text-lg">{currentThemeData.emoji}</span>
            <span className="font-medium">{currentThemeData.name}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              {currentThemeData.colors.map((color, index) => (
                <div
                  key={index}
                  className="w-3 h-3 rounded-full border border-white/30"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            <Palette className="h-4 w-4" />
          </div>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80 p-2 backdrop-blur-xl bg-white/95 dark:bg-black/95 border-2 max-h-96 overflow-y-auto">
        {themeCategories.map((category, categoryIndex) => (
          <div key={category.category}>
            <DropdownMenuLabel className="text-sm font-bold text-gray-600 dark:text-gray-300 px-2 py-1">
              {category.category}
            </DropdownMenuLabel>
            {category.themes.map((theme) => (
              <DropdownMenuItem
                key={theme.id}
                onClick={() => {
                  onThemeChange(theme.id)
                  setIsOpen(false)
                }}
                className="flex items-center justify-between p-3 rounded-lg cursor-pointer hover:bg-white/50 dark:hover:bg-black/50 transition-all duration-200 group"
              >
                <div className="flex items-center gap-3">
                  <span className="text-lg group-hover:scale-110 transition-transform">{theme.emoji}</span>
                  <div>
                    <div className="font-medium text-sm">{theme.name}</div>
                    <div className="flex gap-1 mt-1">
                      {theme.colors.map((color, index) => (
                        <div
                          key={index}
                          className="w-3 h-3 rounded-full border border-gray-300 group-hover:scale-110 transition-transform"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                {currentTheme === theme.id && (
                  <div className="flex items-center gap-1">
                    <Check className="h-4 w-4 text-green-500" />
                    <Sparkles className="h-3 w-3 text-yellow-500 animate-pulse" />
                  </div>
                )}
              </DropdownMenuItem>
            ))}
            {categoryIndex < themeCategories.length - 1 && <DropdownMenuSeparator className="my-2" />}
          </div>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
