"use client"

import { useState, useEffect } from "react"
import { Palette, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const themes = [
  {
    id: "light-academia",
    name: "Light Academia",
    description: "Clean and bright",
    colors: ["#f8fafc", "#e2e8f0", "#cbd5e1"],
  },
  {
    id: "dark-academia",
    name: "Dark Academia",
    description: "Warm and scholarly",
    colors: ["#451a03", "#78350f", "#d97706"],
  },
  {
    id: "forest",
    name: "Forest Sanctuary",
    description: "Natural and calming",
    colors: ["#064e3b", "#065f46", "#10b981"],
  },
  {
    id: "ocean",
    name: "Ocean Depths",
    description: "Deep and focused",
    colors: ["#0c4a6e", "#0369a1", "#0ea5e9"],
  },
  {
    id: "sunset",
    name: "Golden Sunset",
    description: "Warm and inspiring",
    colors: ["#7c2d12", "#ea580c", "#fb923c"],
  },
  {
    id: "lavender",
    name: "Lavender Dreams",
    description: "Soft and peaceful",
    colors: ["#581c87", "#7c3aed", "#a78bfa"],
  },
  {
    id: "rose",
    name: "Rose Garden",
    description: "Elegant and refined",
    colors: ["#881337", "#e11d48", "#fb7185"],
  },
  {
    id: "minimalist",
    name: "Pure Minimalist",
    description: "Clean and distraction-free",
    colors: ["#18181b", "#3f3f46", "#71717a"],
  },
]

export function ThemeToggle() {
  const [currentTheme, setCurrentTheme] = useState("light-academia")

  useEffect(() => {
    const savedTheme = localStorage.getItem("study-buddy-theme") || "light-academia"
    console.log("Loading saved theme:", savedTheme)
    setCurrentTheme(savedTheme)
    applyTheme(savedTheme)
  }, [])

  const applyTheme = (themeId: string) => {
    console.log("Applying theme:", themeId) // Debug log

    // Remove all theme classes
    themes.forEach((theme) => {
      document.documentElement.classList.remove(`theme-${theme.id}`)
    })

    // Add the selected theme class
    document.documentElement.classList.add(`theme-${themeId}`)

    // Set dark mode for certain themes
    const darkThemes = ["dark-academia", "forest", "ocean", "sunset", "lavender", "rose", "minimalist"]
    if (darkThemes.includes(themeId)) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }

    console.log("Theme applied, classes:", document.documentElement.classList.toString())
  }

  const selectTheme = (themeId: string) => {
    setCurrentTheme(themeId)
    localStorage.setItem("study-buddy-theme", themeId)
    applyTheme(themeId)
  }

  const currentThemeData = themes.find((t) => t.id === currentTheme) || themes[0]

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="border-2 backdrop-blur-sm bg-white/10 dark:bg-black/10 hover:bg-white/20 dark:hover:bg-black/20 transition-all duration-300"
        >
          <Palette className="h-4 w-4 mr-2" />
          {currentThemeData.name}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-64 p-2 backdrop-blur-xl bg-white/90 dark:bg-black/90 border-2">
        <div className="grid gap-2">
          {themes.map((theme) => (
            <DropdownMenuItem
              key={theme.id}
              onClick={() => selectTheme(theme.id)}
              className="flex items-center justify-between p-3 rounded-lg cursor-pointer hover:bg-white/50 dark:hover:bg-black/50 transition-all duration-200"
            >
              <div className="flex items-center space-x-3">
                <div className="flex space-x-1">
                  {theme.colors.map((color, index) => (
                    <div
                      key={index}
                      className="w-4 h-4 rounded-full border-2 border-white/50"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                <div>
                  <div className="font-medium text-sm">{theme.name}</div>
                  <div className="text-xs opacity-70">{theme.description}</div>
                </div>
              </div>
              {currentTheme === theme.id && <Check className="h-4 w-4 text-green-500" />}
            </DropdownMenuItem>
          ))}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
