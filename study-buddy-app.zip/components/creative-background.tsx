"use client"

import { useEffect, useState, useRef } from "react"

interface CreativeBackgroundProps {
  theme: string
}

export function CreativeBackground({ theme }: CreativeBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })

  // Update dimensions on resize
  useEffect(() => {
    const updateDimensions = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      })
    }

    updateDimensions()
    window.addEventListener("resize", updateDimensions)
    return () => window.removeEventListener("resize", updateDimensions)
  }, [])

  // Draw background effects based on theme
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    canvas.width = dimensions.width
    canvas.height = dimensions.height

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Create gradient background
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
    gradient.addColorStop(0, getComputedStyle(document.documentElement).getPropertyValue("--gradient-start"))
    gradient.addColorStop(1, getComputedStyle(document.documentElement).getPropertyValue("--gradient-end"))
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Draw theme-specific effects
    if (theme === "cyberpunk") {
      drawCyberpunkEffect(ctx, canvas.width, canvas.height)
    } else if (theme === "aesthetic-pink" || theme === "aesthetic-purple" || theme === "lavender-dreams") {
      drawAestheticEffect(ctx, canvas.width, canvas.height)
    } else if (theme === "forest-green" || theme === "ocean-blue" || theme === "sage-green") {
      drawNatureEffect(ctx, canvas.width, canvas.height)
    } else if (theme === "dark-academia" || theme === "light-academia" || theme === "vintage-blue") {
      drawAcademiaEffect(ctx, canvas.width, canvas.height)
    } else {
      drawDefaultEffect(ctx, canvas.width, canvas.height)
    }
  }, [dimensions, theme])

  // Cyberpunk effect with grid lines and glowing dots
  const drawCyberpunkEffect = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Grid lines
    ctx.strokeStyle = "rgba(0, 255, 136, 0.1)"
    ctx.lineWidth = 1

    // Horizontal lines
    for (let y = 0; y < height; y += 40) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(width, y)
      ctx.stroke()
    }

    // Vertical lines
    for (let x = 0; x < width; x += 40) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, height)
      ctx.stroke()
    }

    // Glowing dots
    for (let i = 0; i < 50; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const radius = Math.random() * 3 + 1

      const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius * 4)
      gradient.addColorStop(0, "rgba(0, 255, 136, 0.8)")
      gradient.addColorStop(0.5, "rgba(0, 255, 136, 0.3)")
      gradient.addColorStop(1, "rgba(0, 255, 136, 0)")

      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(x, y, radius * 4, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  // Aesthetic effect with soft shapes and gradients
  const drawAestheticEffect = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Soft circles
    for (let i = 0; i < 15; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const radius = Math.random() * 200 + 50

      const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius)
      gradient.addColorStop(0, "rgba(255, 255, 255, 0.1)")
      gradient.addColorStop(1, "rgba(255, 255, 255, 0)")

      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)
      ctx.fill()
    }

    // Sparkles
    for (let i = 0; i < 100; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const size = Math.random() * 2 + 0.5

      ctx.fillStyle = "rgba(255, 255, 255, 0.3)"
      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  // Nature effect with organic patterns
  const drawNatureEffect = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Leaf-like patterns
    for (let i = 0; i < 20; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const size = Math.random() * 100 + 50
      const rotation = Math.random() * Math.PI * 2

      ctx.save()
      ctx.translate(x, y)
      ctx.rotate(rotation)
      ctx.fillStyle = "rgba(255, 255, 255, 0.05)"
      ctx.beginPath()
      ctx.ellipse(0, 0, size / 2, size, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
    }

    // Dots pattern
    for (let i = 0; i < 200; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const size = Math.random() * 3 + 0.5

      ctx.fillStyle = "rgba(255, 255, 255, 0.1)"
      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  // Academia effect with subtle texture
  const drawAcademiaEffect = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Paper texture
    for (let i = 0; i < 5000; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const size = Math.random() * 1 + 0.2

      ctx.fillStyle = `rgba(0, 0, 0, ${Math.random() * 0.02})`
      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    // Subtle ink splatters
    for (let i = 0; i < 10; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const radius = Math.random() * 50 + 10

      ctx.fillStyle = "rgba(0, 0, 0, 0.02)"
      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)
      ctx.fill()

      // Small dots around the splatter
      const numDots = Math.floor(Math.random() * 10) + 5
      for (let j = 0; j < numDots; j++) {
        const angle = Math.random() * Math.PI * 2
        const distance = Math.random() * radius * 1.5
        const dotX = x + Math.cos(angle) * distance
        const dotY = y + Math.sin(angle) * distance
        const dotSize = Math.random() * 2 + 0.5

        ctx.fillStyle = "rgba(0, 0, 0, 0.03)"
        ctx.beginPath()
        ctx.arc(dotX, dotY, dotSize, 0, Math.PI * 2)
        ctx.fill()
      }
    }
  }

  // Default effect with subtle particles
  const drawDefaultEffect = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    // Subtle particles
    for (let i = 0; i < 100; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const size = Math.random() * 3 + 0.5

      ctx.fillStyle = "rgba(255, 255, 255, 0.1)"
      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    // Soft gradient overlays
    for (let i = 0; i < 5; i++) {
      const x = Math.random() * width
      const y = Math.random() * height
      const radius = Math.random() * 300 + 100

      const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius)
      gradient.addColorStop(0, "rgba(255, 255, 255, 0.03)")
      gradient.addColorStop(1, "rgba(255, 255, 255, 0)")

      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 -z-10 transition-opacity duration-1000"
      width={dimensions.width}
      height={dimensions.height}
    />
  )
}
