"use client"

import { Button } from "@/components/ui/button"

interface SimpleThemeToggleProps {
  currentTheme: string
  onThemeChange: (theme: string) => void
}

export function SimpleThemeToggle({ currentTheme, onThemeChange }: SimpleThemeToggleProps) {
  const themes = [
    { id: "light-academia", name: "Light Academia" },
    { id: "dark-academia", name: "Dark Academia" },
    { id: "aesthetic-pink", name: "Aesthetic Pink" },
    { id: "aesthetic-purple", name: "Aesthetic Purple" },
    { id: "chic-minimal", name: "Chic Minimal" },
    { id: "chic-gold", name: "Chic Gold" },
    { id: "cottagecore", name: "Cottagecore" },
    { id: "cyberpunk", name: "Cyberpunk" },
    { id: "forest-green", name: "Forest Green" },
    { id: "ocean-blue", name: "Ocean Blue" },
    { id: "sunset-orange", name: "Sunset Orange" },
    { id: "lavender-dreams", name: "Lavender Dreams" },
    { id: "rose-gold", name: "Rose Gold" },
    { id: "mint-fresh", name: "Mint Fresh" },
    { id: "coffee-brown", name: "Coffee Brown" },
    { id: "midnight-black", name: "Midnight Black" },
    { id: "cream-beige", name: "Cream Beige" },
    { id: "sage-green", name: "Sage Green" },
    { id: "dusty-rose", name: "Dusty Rose" },
    { id: "vintage-blue", name: "Vintage Blue" },
  ]

  return (
    <div className="flex gap-2">
      {themes.map((theme) => (
        <Button
          key={theme.id}
          variant={currentTheme === theme.id ? "default" : "outline"}
          onClick={() => onThemeChange(theme.id)}
        >
          {theme.name}
        </Button>
      ))}
    </div>
  )
}
